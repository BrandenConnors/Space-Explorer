

def pleiadean_mission():
    pleiadean_banner()

def pleiadean_logo():
    print(""" 
                                          ___  _       _           _                  _    
                                         | _ \| | ___ (_) __ _  __| | ___  __ _  _ _ ( )___
                                         |  _/| |/ -_)| |/ _` |/ _` |/ -_)/ _` || ' \|/(_-<
                                         |_|  |_|\___||_|\__,_|\__,_|\___|\__,_||_||_| /__/
    """)
def pleiadean_banner():
        print("""
                .______    __       _______  __       ___       _______   _______      ___      .__   __.  __     _______.
                |   _  \  |  |     |   ____||  |     /   \     |       \ |   ____|    /   \     |  \ |  | (_ )   /       |
                |  |_)  | |  |     |  |__   |  |    /  ^  \    |  .--.  ||  |__      /  ^  \    |   \|  |  |/   |   (----`
                |   ___/  |  |     |   __|  |  |   /  /_\  \   |  |  |  ||   __|    /  /_\  \   |  . `  |        \   \    
                |  |      |  `----.|  |____ |  |  /  _____  \  |  '--'  ||  |____  /  _____  \  |  |\   |    .----)   |   
                | _|      |_______||_______||__| /__/     \__\ |_______/ |_______|/__/     \__\ |__| \__|    |_______/    
                                .___  ___.  __       _______.     _______. __    ______   .__   __. 
                                |   \/   | |  |     /       |    /       ||  |  /  __  \  |  \ |  | 
                                |  \  /  | |  |    |   (----`   |   (----`|  | |  |  |  | |   \|  | 
                                |  |\/|  | |  |     \   \        \   \    |  | |  |  |  | |  . `  | 
                                |  |  |  | |  | .----)   |   .----)   |   |  | |  `--'  | |  |\   | 
                                |__|  |__| |__| |_______/    |_______/    |__|  \______/  |__| \__| 

On a lush planet, in the Andromeda Galexy. A usually peaceful spiecies was enjoying the many benifits of the being in close proximity
to one of the galexy's most amzaing phenomenon. A natuaral gravity well slowing fed dark matter into the wormhole Gargantuan.
This lead to time slowing down the the Pleiadian's living century long lives on their home planet. That is until the humans showed up and 
ran off with the dark matter. You have been tasked with hunting down the perpertrators and bringing back the dark matter to save your species....""")

def martian_mission():
    martian_banner()
    
def martian_banner():
        print("""
.___  ___.      ___      .______     .___________. __       ___      .__   __.       .___  ___.  __       _______.     _______. __    ______   .__   __. 
|   \/   |     /   \     |   _  \    |           ||  |     /   \     |  \ |  |       |   \/   | |  |     /       |    /       ||  |  /  __  \  |  \ |  | 
|  \  /  |    /  ^  \    |  |_)  |   `---|  |----`|  |    /  ^  \    |   \|  |       |  \  /  | |  |    |   (----`   |   (----`|  | |  |  |  | |   \|  | 
|  |\/|  |   /  /_\  \   |      /        |  |     |  |   /  /_\  \   |  . `  |       |  |\/|  | |  |     \   \        \   \    |  | |  |  |  | |  . `  | 
|  |  |  |  /  _____  \  |  |\  \----.   |  |     |  |  /  _____  \  |  |\   |       |  |  |  | |  | .----)   |   .----)   |   |  | |  `--'  | |  |\   | 
|__|  |__| /__/     \__\ | _| `._____|   |__|     |__| /__/     \__\ |__| \__|       |__|  |__| |__| |_______/    |_______/    |__|  \______/  |__| \__| 
                                                                                                                                                         

                                Time has stood still, you emerage from cyrosleep in the year 2278.
                                From deep under the surface of the red planet. 
                                Your sentinials have reported the impending death of the nearest red star. 
                                You begin the preparations to wake the rest of the colony for 
                                evacuation when an urgent update comes in from a sentinial on the edge of the galexy.
                                THe Greys just arrived through the Einstein-Rosen bridg.... This must be really bad...
    """)
    
def martian_logo():
    print(""" 
                                               __  __          _   _           _    
                                              |  \/  |__ _ _ _| |_(_)__ _ _ _ ( )___
                                              | |\/| / _` | '_|  _| / _` | ' \|/(_-<
                                              |_|  |_\__,_|_|  \__|_\__,_|_||_| /__/

    """)

def human_mission():
    human_banner()
    

def human_logo():
    print(""" 
                                              _  _                          _    
                                             | || | _  _  _ __   __ _  _ _ ( )___
                                             | __ || || || '  \ / _` || ' \|/(_-<
                                             |_||_| \_,_||_|_|_|\__,_||_||_| /__/

    """)
def human_banner():
        print("""
 __    __   __    __  .___  ___.      ___      .__   __.  __     _______.   .___  ___.  __       _______.     _______. __    ______   .__   __. 
|  |  |  | |  |  |  | |   \/   |     /   \     |  \ |  | (_ )   /       |   |   \/   | |  |     /       |    /       ||  |  /  __  \  |  \ |  | 
|  |__|  | |  |  |  | |  \  /  |    /  ^  \    |   \|  |  |/   |   (----`   |  \  /  | |  |    |   (----`   |   (----`|  | |  |  |  | |   \|  | 
|   __   | |  |  |  | |  |\/|  |   /  /_\  \   |  . `  |        \   \       |  |\/|  | |  |     \   \        \   \    |  | |  |  |  | |  . `  | 
|  |  |  | |  `--'  | |  |  |  |  /  _____  \  |  |\   |    .----)   |      |  |  |  | |  | .----)   |   .----)   |   |  | |  `--'  | |  |\   | 
|__|  |__|  \______/  |__|  |__| /__/     \__\ |__| \__|    |_______/       |__|  |__| |__| |_______/    |_______/    |__|  \______/  |__| \__| 
                                                                                                                                                
                                                The Human race depends on you...
          With the pending death of our closest star, the Sun. A mission has been devised to harness dark energy from a remote 
                                       solar system in an attempt to restart the sun.
    """)

def grey_mission():
    grey_banner()

def grey_banner():
        print(""" 
  _______ .______       _______ ____    ____  __     _______.         .___  ___.  __       _______.     _______. __    ______   .__   __. 
 /  _____||   _  \     |   ____|\   \  /   / (_ )   /       |         |   \/   | |  |     /       |    /       ||  |  /  __  \  |  \ |  | 
|  |  __  |  |_)  |    |  |__    \   \/   /   |/   |   (----`         |  \  /  | |  |    |   (----`   |   (----`|  | |  |  |  | |   \|  | 
|  | |_ | |      /     |   __|    \_    _/          \   \             |  |\/|  | |  |     \   \        \   \    |  | |  |  |  | |  . `  | 
|  |__| | |  |\  \----.|  |____     |  |        .----)   |            |  |  |  | |  | .----)   |   .----)   |   |  | |  `--'  | |  |\   | 
 \______| | _| `._____||_______|    |__|        |_______/             |__|  |__| |__| |_______/    |_______/    |__|  \______/  |__| \__| 
                                                                                                                                          
                                      Your mission should you choose to accept it...
           Sent back in time, to stop the human race, your race. At least it used to be your race before the 
                haldron colider malfunction split the universe into the many fractions of the multiverse.
    """)


def grey_logo():
    print(""" 
                                                   ___                  _    
                                                  / __| _ _  ___  _  _ ( )___
                                                 | (_ || '_|/ -_)| || ||/(_-<
                                                  \___||_|  \___| \_, |  /__/
                                                                  |__/       
    """)

def main_logo():
    print("""
         )\.--.     /`-.     /`-.      )\.-.   )\.---.        )\.---.       .'(     /`-.   .')         .-./(     /`-.   )\.---.     /`-.  
         (   ._.'  ,' _  \  ,' _  \   ,' ,-,_) (   ,-._(      (   ,-._(  ,') \  )  ,' _  \ ( /        ,'     )  ,' _  \ (   ,-._(  ,' _  \ 
          `-.`.   (  '-' ( (  '-' (  (  .   _   \  '-,         \  '-,   (  '/  /  (  '-' (  ))       (  .-, (  (  '-' (  \  '-,   (  '-' ( 
         ,_ (  \   ) ,._.'  )   _  )  ) '..' )   ) ,-`          ) ,-`    )     )   ) ,._.'  )'._.-.   ) '._\ )  ) ,_ .'   ) ,-`    ) ,_ .' 
        (  '.)  ) (  '     (  ,' ) \ (  ,   (   (  ``-.        (  ``-.  (  .'\ \  (  '     (       ) (  ,   (  (  ' ) \  (  ``-.  (  ' ) \ 
         '._,_.'   )/       )/    )/  )/'._.'    )..-.(         )..-.(   )/   )/   )/       )/,__.'   )/ ._.'   )/   )/   )..-.(   )/   )/ 

                                  ----------- Welcome Adventurer, are you prepared to play?!?! -----------     
                                        ------ Before we get started, Please Choose your Race... ------   
  _  _                           _    ___                   _   __  __          _   _                _   ___ _     _         _               _    
 | || |_  _ _ __  __ _ _ _  ___ | |  / __|_ _ ___ _  _ ___ | | |  \/  |__ _ _ _| |_(_)__ _ _ _  ___ | | | _ \ |___(_)__ _ __| |___ __ _ _ _ ( )___
 | __ | || | '  \/ _` | ' \(_-< | | | (_ | '_/ -_) || (_-< | | | |\/| / _` | '_|  _| / _` | ' \(_-< | | |  _/ / -_) / _` / _` / -_) _` | ' \|/(_-<
 |_||_|\_,_|_|_|_\__,_|_||_/__/ | |  \___|_| \___|\_, /__/ | | |_|  |_\__,_|_|  \__|_\__,_|_||_/__/ | | |_| |_\___|_\__,_\__,_\___\__,_|_||_| /__/
                                |_|               |__/     |_|                                      |_|                                           

                                                            1) Humans
                                                            2) Greys
                                                            3) Martians
                                                            4) Pleiadeans
                                                            5) Exit                                                                                                                   """)

def ship():
    print("""
                       ___ _                                           ___                      _    _      _ 
                      / __| |_  ___  ___ ___ ___   _  _ ___ _  _ _ _  / __|_ __  __ _ __ ___ __| |_ (_)_ __(_)
                     | (__| ' \/ _ \/ _ (_-</ -_) | || / _ \ || | '_| \__ \ '_ \/ _` / _/ -_|_-< ' \| | '_ \_ 
                      \___|_||_\___/\___/__/\___|  \_, \___/\_,_|_|   |___/ .__/\__,_\__\___/__/_||_|_| .__(_)
                                                   |__/                   |_|                         |_|     
                                                          1) Tie-Fighter
                                                          2) Millienum Falcon
                                                          3) Voyager
                                                          4) Serenity
                                                          5) End Game
    """)

def starmap():
    print("""
                                         .              +   .                .   . .     .  .
                                                       .                    .       .     *
                                      .       *                        . . . .  .   .  + .
                                                "You Are Here"            .   .  +  . . .
                                    .                 |             .  .   .    .    . .
                                                      |           .     .     . +.    +  .
                                                     \|/            .       .   . .
                                            . .       V          .    * . . .  .  +   .
                                               +      .           .   .      +
                                                                .       . +  .+. .
                                      .                      .     . + .  . .     .      .
                                               .      .    .     . .   . . .        ! /
                                          *             .    . .  +    .  .       - O -
                                              .     .    .  +   . .  *  .       . / |
                                                   . + .  .  .  .. +  .
                                    .      .  .  .  *   .  *  . +..  .            *
                                     .      .   . .   .   .   . .  +   .    .            +
                                                               """)

# def hud():
#     print(f"""
#                                                                                                         **___---HUD---___**
#                                                                                                         Race:{character.name}
#                                                                                                         Health :{character.hp}

#                                                                                                         Ship: {vessel.name}
#                                                                                                         Shields: {vessel.hp}
#                                                                                                         Phasers: {vessel.damage}""")


# def ship_choice():
#     print(f"""
#                                         Congratulations! you have chosen to fly: {vessel.name}
#                                                             Sheild: {vessel.hp}
#                                                             Damage: {vessel.damage}
#                                      .              +   .                .   . .     .  .
#                                                        .                    .       .     *
#                                       .       *                        . . . .  .   .  + .
#                                                 "You Are Here"            .   .  +  . . .
#                                     .                 |             .  .   .    .    . .
#                                                       |           .     .     . +.    +  .
#                                                      \|/            .       .   . .
#                                             . .       V          .    * . . .  .  +   .
#                                                +      .           .   .      +
#                                                                 .       . +  .+. .
#                                       .                      .     . + .  . .     .      .
#                                                .      .    .     . .   . . .        ! /
#                                           *             .    . .  +    .  .       - O -
#                                               .     .    .  +   . .  *  .       . / |
#                                                    . + .  .  .  .. +  .
#                                     .      .  .  .  *   .  *  . +..  .            *
#                                      .      .   . .   .   .   . .  +   .    .            +
#                                                                """)
